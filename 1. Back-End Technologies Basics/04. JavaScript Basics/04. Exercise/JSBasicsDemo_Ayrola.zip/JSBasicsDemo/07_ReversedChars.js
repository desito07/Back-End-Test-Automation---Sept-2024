function reversedChars(arr)
{
    let result = `${arr[2]} ${arr[1]} ${arr[0]}`;

    console.log(result);
}

reversedChars(['A', 'B', 'C'])