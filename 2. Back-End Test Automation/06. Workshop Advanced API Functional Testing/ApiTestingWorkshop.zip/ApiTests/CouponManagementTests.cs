﻿using NUnit.Framework;
using RestSharp;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Drawing;
using Newtonsoft.Json;

namespace ApiTests
{
    [TestFixture]
    public class CouponManagementTests
    {
        private RestClient client;
        private string adminToken;
        private string userToken;

        [SetUp]
        public void Setup()
        {
            client = new RestClient(GlobalConstants.BaseUrl);
            adminToken = GlobalConstants.AuthenticateUser("admin@gmail.com", "admin@gmail.com");
            userToken = GlobalConstants.AuthenticateUser("john.doe@example.com", "password123");
        }

        [TearDown]
        public void Dispose()
        {
            client.Dispose();
        }

        [Test]
        public void CouponLifecycleTest()
        {
            var getProductsRequest = new RestRequest("/product", Method.Get);
            getProductsRequest.AddHeader("Authorization", $"Bearer {adminToken}");

            var getProductsResponse = client.Execute(getProductsRequest);
            Assert.That(getProductsResponse.IsSuccessful, Is.True, "Fetching products failed");

            var products = JArray.Parse(getProductsResponse.Content);
            Assert.That(products.Count, Is.GreaterThanOrEqualTo(2), 
                "Not enough products available for the test");

            var random = new Random();
            var productIds = products.Select(p => p["_id"]?.ToString()).ToList();
            string firstProductId = productIds[random.Next(productIds.Count)];
            string secondProductId = productIds[random.Next(productIds.Count)];

            while (firstProductId == secondProductId)
            {
                secondProductId = productIds[random.Next(productIds.Count)];
            }

            var createCouponRequest = new RestRequest("/coupon", Method.Post);
            createCouponRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            createCouponRequest.AddJsonBody(new
            {
                Name = "DISCOUNT20",
                Discount = 20,
                Expiry = "2024-12-31"
            });

            var createCouponResponse = client.Execute(createCouponRequest);
            Assert.That(createCouponResponse.IsSuccessful, Is.True, "Coupon creation failed");

            string couponId = JObject.Parse(createCouponResponse.Content)["_id"]?.ToString();
            Assert.That(couponId, Is.Not.Null.Or.Empty, "Coupon ID should not be null or empty");

            var createCartRequest = new RestRequest("/user/cart", Method.Post);
            createCartRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            createCartRequest.AddJsonBody(new
            {
                cart = new[]
                {
                    new { _id = firstProductId, count = 1, color = "red" },
                    new { _id = secondProductId, count = 2, color = "blue" }
                }
            });

            var createCartResponse = client.Execute(createCartRequest);
            Assert.That(createCartResponse.IsSuccessful, Is.True, "Cart creation failed");

            var applyCouponRequest = new RestRequest("/user/cart/applycoupon", Method.Post);
            applyCouponRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            applyCouponRequest.AddJsonBody(new
            {
                Coupon = "DISCOUNT20"
            });

            var applyCouponResponse = client.Execute(applyCouponRequest);

            Assert.That(applyCouponResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK),
                "Expected status code OK (200)");

            var deleteCouponRequest = new RestRequest($"/coupon/{couponId}", Method.Delete);
            deleteCouponRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            var deleteCouponResponse = client.Execute(deleteCouponRequest);
            Assert.That(deleteCouponResponse.IsSuccessful, Is.True, "Coupon deletion failed");

            var verifyCouponRequest = new RestRequest($"/coupon/{couponId}", Method.Get);
            verifyCouponRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            var verifyCouponResponse = client.Execute(verifyCouponRequest);
            Assert.That(verifyCouponResponse.Content, Is.Null.Or.EqualTo("null"), 
                "Coupon still exists after deletion");
        }

        [Test]
        public void CouponApplicationToOrderTest()
        {
            var getProductsRequest = new RestRequest("/product", Method.Get);  
            getProductsRequest.AddHeader("Authorization", $"Bearer {adminToken}");

            var getProductsResponse = client.Execute(getProductsRequest);
            Assert.That(getProductsResponse.IsSuccessful, Is.True, "Fetching products failed");

            var products = JArray.Parse(getProductsResponse.Content);
            Assert.That(products.Count, Is.GreaterThan(0), "No products available for the test");

            string productId = products.First()["_id"]?.ToString();
            Assert.That(productId, Is.Not.Null.Or.Empty, "Product ID should not be null or empty");

            var createCouponRequest = new RestRequest("/coupon", Method.Post);
            createCouponRequest.AddHeader("Authorization", $"Bearer {adminToken}");
            createCouponRequest.AddJsonBody(new
            {
                Name = "SAVE10",
                Discount = 10,
                Expiry = "2026-12-31"
            });

            var createCouponResponse = client.Execute(createCouponRequest);
            Assert.That(createCouponResponse.IsSuccessful, Is.True, "Coupon creation failed");

            var addToCartRequest = new RestRequest("/user/cart", Method.Post);
            addToCartRequest.AddHeader("Authorization", $"Bearer {userToken}");
            addToCartRequest.AddJsonBody(new
            {
                cart = new[]
                {
                    new { _id = productId, count = 2, color = "Red" }
                }
            });

            var addToCartResponse = client.Execute(addToCartRequest);
            Assert.That(addToCartResponse.IsSuccessful, Is.True, "Adding product to cart failed");

            var applyCouponRequest = new RestRequest("/user/cart/applycoupon", Method.Post);
            applyCouponRequest.AddHeader("Authorization", $"Bearer {userToken}");
            applyCouponRequest.AddJsonBody(new
            {
                coupon = "SAVE10"
            });

            var applyCouponResponse = client.Execute(applyCouponRequest);
            Assert.That(applyCouponResponse.IsSuccessful, Is.True, "Applying coupon to cart failed");

            var placeOrderRequest = new RestRequest("/user/cart/cash-order", Method.Post);
            placeOrderRequest.AddHeader("Authorization", $"Bearer {userToken}");
            placeOrderRequest.AddJsonBody(JsonConvert.SerializeObject(new
            {
                COD = true,
                couponApplied = false
            }));

            var placeOrderResponse = client.Execute(placeOrderRequest);
            Assert.That(placeOrderResponse.IsSuccessful, Is.True, "Placing order failed");
        }
    }
}
