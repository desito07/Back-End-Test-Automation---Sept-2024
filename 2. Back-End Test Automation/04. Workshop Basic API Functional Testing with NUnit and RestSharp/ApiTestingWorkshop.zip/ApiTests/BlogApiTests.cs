﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System.Net;

namespace ApiTests
{
    [TestFixture]
    public class BlogApiTests : IDisposable
    {
        private RestClient client;
        private string token;

        [SetUp]
        public void Setup()
        {
            client = new RestClient(GlobalConstants.BaseUrl);
            token = GlobalConstants.AuthenticateUser("admin@gmail.com", "admin@gmail.com");

            Assert.That(token, Is.Not.Null.Or.Empty, "Authentication token should not be null or empty");
        }

        [Test]
        public void Test_GetAllBlogs()
        {
            var request = new RestRequest("blog", Method.Get);

            var response = client.Execute(request);

            Assert.Multiple(() =>
            {
                Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK), 
                    "Expected status code OK (200)");
                Assert.That(response.Content, Is.Not.Empty, "Response content should not be empty");

                var blogs = JArray.Parse(response.Content);

                Assert.That(blogs.Type, Is.EqualTo(JTokenType.Array), 
                    "Expected response content to be a JSON array");
                Assert.That(blogs.Count, Is.GreaterThan(0), "Expected at least one blog in the response");

                foreach (var blog in blogs)
                {
                    Assert.That(blog["title"]?.ToString(), Is.Not.Null.And.Not.Empty, 
                        "Blog title should not be null or empty");
                    Assert.That(blog["description"]?.ToString(), Is.Not.Null.And.Not.Empty, 
                        "Blog description should not be null or empty");
                    Assert.That(blog["author"]?.ToString(), Is.Not.Null.And.Not.Empty, 
                        "Blog author should not be null or empty");
                    Assert.That(blog["category"]?.ToString(), Is.Not.Null.And.Not.Empty, 
                        "Blog category should not be null or empty");
                }
            });
        }

        [Test]
        public void Test_AddBlog()
        {
            var request = new RestRequest("blog", Method.Post);
            request.AddHeader("Authorization", $"Bearer {token}");
            request.AddJsonBody(new
            {
                title = "New Blog",
                description = "New Blog Description",
                category = "Technology"
            });

            var response = client.Execute(request);

            Assert.Multiple(() =>
            {
                Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK), 
                    "Expected status code OK (200)");
                Assert.That(response.Content, Is.Not.Empty, "Response content should not be empty");

                var content = JObject.Parse(response.Content);

                Assert.That(content["title"]?.ToString(), Is.EqualTo("New Blog"), 
                    "Blog title should match the input");
                Assert.That(content["description"]?.ToString(), Is.EqualTo("New Blog Description"), 
                    "Blog description should match the input");
                Assert.That(content["category"]?.ToString(), Is.EqualTo("Technology"), 
                    "Blog category should match the input");
                Assert.That(content["author"]?.ToString(), Is.Not.Null.And.Not.Empty, 
                    "Blog author should not be null or empty");
            });
        }

        [Test]
        public void Test_UpdateBlog()
        {
            var getRequest = new RestRequest("blog", Method.Get);

            var getResponse = client.Execute(getRequest);

            Assert.That(getResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK), "Failed to retrieve blogs");
            Assert.That(getResponse.Content, Is.Not.Empty, "Get blogs response content is empty");

            var blogs = JArray.Parse(getResponse.Content);
            var blogToUpdate = blogs.FirstOrDefault(b => b["title"]?.ToString() == "10 Tips for a Healthier Lifestyle");

            Assert.That(blogToUpdate, Is.Not.Null, "Blog with title '10 Tips for a Healthier Lifestyle' not found");

            var blogId = blogToUpdate["_id"].ToString();

            var updateRequest = new RestRequest("blog/{id}", Method.Put);
            updateRequest.AddHeader("Authorization", $"Bearer {token}");
            updateRequest.AddUrlSegment("id", blogId);
            updateRequest.AddJsonBody(new
            {
                title = "Updated Blog",
                description = "Updated Description",
                category = "Lifestyle"
            });

            var updateResponse = client.Execute(updateRequest);

            Assert.Multiple(() =>
            {
                Assert.That(updateResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK),
                    "Expected status code OK (200)");
                Assert.That(updateResponse.Content, Is.Not.Empty, "Update response content should not be empty");

                var content = JObject.Parse(updateResponse.Content);

                Assert.That(content["title"]?.ToString(), Is.EqualTo("Updated Blog"),
                    "Blog title should match the updated value");
                Assert.That(content["description"]?.ToString(), Is.EqualTo("Updated Description"), 
                    "Blog description should match the updated value");
                Assert.That(content["category"]?.ToString(), Is.EqualTo("Lifestyle"),
                    "Blog category should match the updated value");
                Assert.That(content["author"]?.ToString(), Is.Not.Null.And.Not.Empty,
                    "Blog author should not be null or empty");

            });
        }


        [Test]
        public void Test_DeleteBlog()
        {
            var getRequest = new RestRequest("blog", Method.Get);
            var getResponse = client.Execute(getRequest);

            Assert.That(getResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK), "Failed to retrieve blogs");
            Assert.That(getResponse.Content, Is.Not.Empty, "Get blogs response content is empty");

            var blogs = JArray.Parse(getResponse.Content);
            var blogToDelete = blogs.FirstOrDefault(b => b["title"]?.ToString() == 
            "The Evolution of Entertainment in the Digital Age");

            Assert.That(blogToDelete, Is.Not.Null, 
                "Blog with title 'The Evolution of Entertainment in the Digital Age' not found");

            var blogId = blogToDelete["_id"].ToString();

            var deleteRequest = new RestRequest("blog/{id}", Method.Delete);
            deleteRequest.AddHeader("Authorization", $"Bearer {token}");
            deleteRequest.AddUrlSegment("id", blogId);

            var deleteResponse = client.Execute(deleteRequest);

            Assert.Multiple(() =>
            {
                Assert.That(deleteResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK),
                    "Expected status code Ok");

                var verifyGetRequest = new RestRequest("blog/{id}", Method.Get);
                verifyGetRequest.AddUrlSegment("id", blogId);

                var verifyGetResponse = client.Execute(verifyGetRequest);

                Assert.That(verifyGetResponse.Content, Is.Null.Or.EqualTo("null"), 
                    "Verify get response content should be empty");
            });
        }

        public void Dispose()
        {
            client?.Dispose();
        }
    }
}
