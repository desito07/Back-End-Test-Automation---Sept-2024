﻿namespace HouseRentingSystem.Services.Data
{
    public class Constants
    {
        public const string AdminEmail = "admin@mail.com";
    }
}